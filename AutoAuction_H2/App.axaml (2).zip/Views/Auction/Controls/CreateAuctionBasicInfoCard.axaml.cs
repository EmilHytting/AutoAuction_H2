using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace AutoAuction_H2.Views.Auction.Controls;

public partial class CreateAuctionBasicInfoCard : UserControl
{
    public CreateAuctionBasicInfoCard()
    {
        InitializeComponent();
    }

    private void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
    }
}
