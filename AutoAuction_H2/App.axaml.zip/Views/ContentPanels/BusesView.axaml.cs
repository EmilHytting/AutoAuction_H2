using Avalonia.Controls;

namespace AutoAuction_H2.Views.ContentPanels
{

    public partial class BusesView : UserControl
    {
        public BusesView()
        {
            InitializeComponent();
        }
    }
}