using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace AutoAuction_H2.Views.ContentPanels;

public partial class TrucksView : UserControl
{
    public TrucksView()
    {
        InitializeComponent();
    }
}

