using Avalonia.Controls;

namespace AutoAuction_H2.Views.ContentPanels
{
    public partial class PrivateCarsView : UserControl
    {
        public PrivateCarsView()
        {
            InitializeComponent();
        }
    }
}
