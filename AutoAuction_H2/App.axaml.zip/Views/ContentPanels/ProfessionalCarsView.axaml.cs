using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace AutoAuction_H2.Views.ContentPanels;

public partial class ProfessionalCarsView : UserControl
{
    public ProfessionalCarsView()
    {
        InitializeComponent();
    }
}