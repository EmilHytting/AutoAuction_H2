using AutoAuction_H2.Models.Entities;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;

namespace AutoAuction_H2.ViewModels
{
    public partial class AuctionOverviewViewModel : ViewModelBase
    {
        private readonly INavigationService _navigation;
        private readonly AuctionService _auctionService;

        public ObservableCollection<AuctionEntity> ActiveAuctions { get; } = new();

        public AuctionOverviewViewModel(INavigationService navigation, AuctionService auctionService)
        {
            _navigation = navigation;
            _auctionService = auctionService;

            // Eksempeldata � kan udskiftes med load fra service
            // ActiveAuctions.Add(new AuctionEntity { ... });
        }

        // Command til XAML binding
        public IRelayCommand<object?> OpenAuctionDetailCommand => new RelayCommand<object?>(OpenAuctionDetail);

        private void OpenAuctionDetail(object? item)
        {
            if (item is AuctionEntity auction)
            {
                var vm = new AuctionDetailViewModel(
                    auction,
                    auction.SellerId == AppState.Instance.UserId,
                    _auctionService
                );

                _navigation.NavigateTo(vm);
            }
        }
    }
}
