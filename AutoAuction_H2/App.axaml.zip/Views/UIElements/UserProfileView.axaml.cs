﻿using Avalonia.Controls;

namespace AutoAuction_H2.Views.UIElements
{
    public partial class UserProfileView : UserControl
    {
        public UserProfileView()
        {
            InitializeComponent();
        }
    }
}
