using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace AutoAuction_H2.Views;

public partial class LogoPanelView : UserControl
{
    public LogoPanelView()
    {
        InitializeComponent();
    }
}