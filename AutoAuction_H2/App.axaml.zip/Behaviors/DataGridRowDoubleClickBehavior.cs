﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Xaml.Interactivity;
using System.Windows.Input;

namespace AutoAuction_H2.Behaviors
{
    public class DataGridRowDoubleClickBehavior : Behavior<DataGrid>
    {
        public static readonly StyledProperty<ICommand?> CommandProperty =
            AvaloniaProperty.Register<DataGridRowDoubleClickBehavior, ICommand?>(nameof(Command));

        public ICommand? Command
        {
            get => GetValue(CommandProperty);
            set => SetValue(CommandProperty, value);
        }

        protected override void OnAttached()
        {
            base.OnAttached();
            AssociatedObject.DoubleTapped += OnDoubleTapped;
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            AssociatedObject.DoubleTapped -= OnDoubleTapped;
        }

        private void OnDoubleTapped(object? sender, RoutedEventArgs e)
        {
            if (sender is DataGrid grid && grid.SelectedItem is { } item)
            {
                if (Command?.CanExecute(item) == true)
                {
                    Command.Execute(item);
                }
            }
        }
    }
}
