﻿using Avalonia.Controls;
using Avalonia.Interactivity;
using System;

namespace AutoAuction_H2.Helpers
{
    public static class DataGridExtensions
    {
        public static void EnableRowDoubleClick(DataGrid grid, Action<AuctionEntity> onOpen)
        {
            grid.DoubleTapped += (s, e) =>
            {
                if (grid.SelectedItem is AuctionEntity auction)
                {
                    onOpen(auction);
                }
            };
        }
    }
}
