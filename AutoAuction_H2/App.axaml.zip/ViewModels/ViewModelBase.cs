﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace AutoAuction_H2.ViewModels
{
    public class ViewModelBase : ObservableObject
    {
    }
}
