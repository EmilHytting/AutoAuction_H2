﻿using AutoAuction_H2.Models.Entities;
using AutoAuction_H2.Services;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace AutoAuction_H2.ViewModels
{
    public class AuctionOverviewViewModel : ViewModelBase
    {
        private readonly AuctionService _auctionService;
        public ObservableCollection<AuctionEntity> ActiveAuctions { get; } = new();

        public AuctionOverviewViewModel(AuctionService auctionService)
        {
            _auctionService = auctionService;
            _ = LoadAsync();
        }

        private async Task LoadAsync()
        {
            try
            {
                var auctions = await _auctionService.GetAuctionsAsync();

                ActiveAuctions.Clear();
                foreach (var auction in auctions)
                    ActiveAuctions.Add(auction);
            }
            catch (System.Exception)
            {
                // TODO: evt. fejlbesked property til UI
            }
        }
    }
}
