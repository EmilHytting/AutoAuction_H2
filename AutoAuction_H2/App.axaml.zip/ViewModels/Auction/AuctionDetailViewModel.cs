﻿using AutoAuction_H2.Models.Entities;
using AutoAuction_H2.Models.Interfaces;
using AutoAuction_H2.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Xunit.Sdk;

namespace AutoAuction_H2.ViewModels
{
    public partial class AuctionDetailViewModel : ViewModelBase
    {
        private readonly AuctionService _auctionService;

        [ObservableProperty] private AuctionEntity item;
        [ObservableProperty] private bool isSeller;
        [ObservableProperty] private string? errorMessage;

        public bool IsBuyer => !IsSeller;

        public ObservableCollection<string> BidHistory { get; } = new();

        public IRelayCommand BackCommand { get; }
        public IAsyncRelayCommand<decimal> PlaceBidCommand { get; }

        public event EventHandler? Closed;

        public AuctionDetailViewModel(AuctionEntity item, bool isSeller, AuctionService auctionService)
        {
            _auctionService = auctionService;
            this.item = item;
            this.isSeller = isSeller;

            BackCommand = new RelayCommand(() => Closed?.Invoke(this, EventArgs.Empty));
            PlaceBidCommand = new AsyncRelayCommand<decimal>(PlaceBidAsync);

            // 🔹 load bud historik når viewmodel skabes
            _ = LoadAuctionAsync();
        }

        private async Task LoadAuctionAsync()
        {
            try
            {
                var fresh = await _auctionService.GetAuctionAsync(Item.Id);
                if (fresh != null)
                {
                    Item = fresh;

                    BidHistory.Clear();
                    foreach (var bid in fresh.Bids.OrderByDescending(b => b.Timestamp))
                    {
                        BidHistory.Add($"{bid.Timestamp:t} User {bid.UserId}: {bid.Amount:N0} kr");
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Kunne ikke hente auktion: {ex.Message}";
            }
        }

        private async Task PlaceBidAsync(decimal amount)
        {
            ErrorMessage = null;

            if (amount <= Item.CurrentBid)
            {
                ErrorMessage = "Buddet skal være højere end det nuværende.";
                return;
            }

            try
            {
                var (success, error) = await _auctionService.PlaceBidAsync(Item.Id, AppState.Instance.UserId, amount);

                if (!success)
                {
                    ErrorMessage = error ?? "Buddet blev afvist af serveren.";
                    return;
                }

                // 🔹 reload auction med nye bud
                await LoadAuctionAsync();
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
            }
        }
    }
}
